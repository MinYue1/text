﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace AD_Pedia.Controllers
{
    [Route("[controller]/[action]")]
    [ApiController]
    public class SearchApi : ControllerBase
    {
    }
}
