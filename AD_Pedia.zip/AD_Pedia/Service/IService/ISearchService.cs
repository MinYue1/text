﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AD_Pedia.Service.IService
{
    public interface ISearchService
    {

        public void Search(string word);

        public void GetSearchHot();


    }
}
