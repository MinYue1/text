﻿namespace AD_Pedia.Service.IService
{ 
    public interface IUserService
    {
        /// <summary>
        /// 登录
        /// </summary>
        public string login(string xx);
        /// <summary>
        /// 注册
        /// </summary>
        public void register();

    }
}
