﻿
using AD_Pedia.Service.IService;

namespace AD_Pedia.Service.ImplementService
{
    public class UserService : IUserService
    {
        public string login(string xx)
        {
            throw new NotImplementedException();
        }

        public void register()
        {
            throw new NotImplementedException();
        }
    }
}
