using System.Data;
using Dapper;
using MySql.Data.MySqlClient;

namespace AD_Pedia.Common.dapper;

public class DapperHelper
{
    //static IDbConnection _dbConnection = null;
    private string ip = null;
    //public string ConnectionString => ConnectionOptions.ConnectionString;
    public DapperHelper(){
        ip = null;
    }
    public DapperHelper(string ip)
    {
        this.ip = ip;
    }
    /// <summary>
    /// 单个查询
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="sql">sql语句</param>
    /// <param name="param">参数</param>
    /// <param name="transaction">事务</param>
    /// <param name="buffered">缓冲/缓存</param>
    /// <param name="commandTimeout">超时时间</param>
    /// <param name="commandType">command类型</param>
    /// <returns></returns>
    public T QueryFirst<T>(string sql, object param = null, IDbTransaction transaction = null,
    bool buffered = true, int? commandTimeout = null, CommandType? commandType = null)
    {
        using (var _dbConnection = ConnectionOptions.DbConnection(ip))
        {
            //
            try
            {
                var result = _dbConnection.QueryFirstOrDefault<T>(sql, param, transaction, commandTimeout, commandType);
                return result;
            }catch(MySql.Data.MySqlClient.MySqlException e)
            {
                Console.WriteLine($"执行SQL: {sql} \nQueryFirst 异常:" + e.Message);
                return default(T);
            }
            finally
            {
                _dbConnection.Close();
            }
            
        }

    }

    /// <summary>
    /// 设置为事务性的
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="sql"></param>
    /// <param name="param"></param>
    /// <param name="transaction"></param>
    /// <param name="buffered"></param>
    /// <param name="commandTimeout"></param>
    /// <param name="commandType"></param>
    /// <returns></returns>
    public T QueryFirstTransactoin<T>(string sql, object param = null, IDbTransaction transaction = null,
    bool buffered = true, int? commandTimeout = null, CommandType? commandType = null){
        //_dbConnection.Open();
        var _dbConnection = ConnectionOptions.DbConnection(ip);
        using (transaction = _dbConnection.BeginTransaction()){
            try{
                var user = _dbConnection.QueryFirstOrDefault<T>(sql,param,transaction,
                commandTimeout, commandType);
                transaction.Commit();
                return user;
            }catch( MySqlException ex){ 
                //执行失败，回滚
                if (transaction != null){
                    transaction.Rollback();
                }
                throw ex;
            }finally{
                _dbConnection.Close();
            }

        }
        
    }

    /// <summary>
    /// 多个查询
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="sql">sql语句</param>
    /// <param name="param">参数</param>
    /// <param name="transaction">事务</param>
    /// <param name="buffered">缓冲/缓存</param>
    /// <param name="commandTimeout">超时时间</param>
    /// <param name="commandType">command类型</param>
    /// <returns>IEnumerable集合</returns>
    public IEnumerable<T> Query<T>(string sql, object param = null, IDbTransaction transaction = null,
    bool buffered = true, int? commandTimeout = null, CommandType? commandType = null){
        //Console.WriteLine(_dbConnection.ConnectionString);
        using(var _dbConnection = ConnectionOptions.DbConnection(ip))
        {
            try
            {
                var result = ConnectionOptions.DbConnection(ip).Query<T>(sql, param, transaction, buffered, commandTimeout, commandType);
                return result;
            }catch (MySqlException ex)
            {
                Console.WriteLine($"执行SQL: {sql} \nQuery 异常:" + ex.Message);
                return default;
            }
            finally
            {
                _dbConnection.Close();
            }
        }
        
    }
    /// <summary>
    /// 增删改 
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <param name="sql"></param>
    /// <param name="param"></param>
    /// <param name="transaction"></param>
    /// <param name="commandTimeout"></param>
    /// <param name="commandType"></param>
    /// <returns></returns>
    public int Execute<T>(string sql, object param = null, IDbTransaction transaction = null,
     int? commandTimeout = null, CommandType? commandType = null){

        using (var _dbConnection = ConnectionOptions.DbConnection(ip))
        {
            try
            {
                int result = ConnectionOptions.DbConnection(ip).Execute(sql, param, transaction, commandTimeout, commandType);
                return result;
            }catch (MySqlException ex)
            {
                Console.WriteLine($"执行SQL: {sql} \nExecute 异常:" + ex.Message);
                return 0;
            }
            finally
            {
                _dbConnection.Close();
            }
            
        }
        
        //if (result != 0)
        //{
        //    var idProperty = typeof(T).GetProperty("Id");
        //    Console.WriteLine("::" + idProperty);
        //    if (idProperty != null)
        //    {
        //        var insertedId = (int)idProperty.GetValue(result);
        //        return insertedId;
        //    }
        //}
                       
    }

}
