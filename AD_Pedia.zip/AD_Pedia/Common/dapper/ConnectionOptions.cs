using System.Configuration;
using System.Data;
using System.Data.Common;
using MySql.Data.MySqlClient;

namespace AD_Pedia.Common.dapper;
/// <summary>
/// 基础设施类
/// </summary>
public class ConnectionOptions
{

    private static string _ConnectionString = "Server=10.160.25.116;database=rfid;Uid=rfid;Pwd=123456;Pooling=true;ConnectionTimeout=60;MaxPoolSize=200;MinPoolSize=10;";
   
    /// <summary>
    /// 连接数据库
    /// </summary>
    /// <param name="conn"></param>
    /// <returns></returns>
    public static IDbConnection DbConnection(string conn)
    {
        string ClientConnString = null;
        if (conn != null)
        {
            switch (conn)
            {
                case "10.160.17.29": //appdnan32
                    {
                        ClientConnString = $"Server={conn};Port=3306;Database=rfid_migration;Uid=rfid_readOnly;Pwd=rfid_readOnly23rfid_readOnly;Pooling=true;ConnectionTimeout=60;MaxPoolSize=200;MinPoolSize=10;";
                        //Console.WriteLine("Hai :" + ClientConnString);
                    }break;
                default://生产机子本地数据库
                    {
                        ClientConnString = $"Server={conn};Port=3306;Database=rfid_4;Uid=rfid;Pwd=123456;Pooling=true;ConnectionTimeout=60;MaxPoolSize=200;MinPoolSize=10;";
                    }break;
            }
            
        }
        
        using (var _dbConnection = new MySqlConnection()) {
            if (string.IsNullOrEmpty(_dbConnection.ConnectionString))
            {
                if (string.IsNullOrEmpty(conn))
                {
                    _dbConnection.ConnectionString = _ConnectionString;
                }
                else _dbConnection.ConnectionString = ClientConnString;
            }
            return _dbConnection;
        }
        
    }

    /// 数据库连接字符串
    //public static string ConnectionString
    //{
    //    get => _ConnectionString;
    //    set => _ConnectionString = value;
    //}

}
